/**
 * OAuth related classes
 */
package twitter4j.auth;