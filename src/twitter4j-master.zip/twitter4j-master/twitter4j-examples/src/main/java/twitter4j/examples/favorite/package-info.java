/**
 * example codes for favorite resources
 */
package twitter4j.examples.favorite;