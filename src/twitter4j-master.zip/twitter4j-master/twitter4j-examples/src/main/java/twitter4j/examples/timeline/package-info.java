/**
 * example codes for timeline resources
 */
package twitter4j.examples.timeline;