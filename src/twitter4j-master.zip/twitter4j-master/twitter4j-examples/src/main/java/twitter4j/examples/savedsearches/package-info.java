/**
 * example codes for saved searches resources
 */
package twitter4j.examples.savedsearches;